var NFT = artifacts.require("./NFT.sol");

var AUCTION = artifacts.require("./NFTAuction.sol");

module.exports = function(deployer) {
  deployer.deploy(NFT);

  deployer.deploy(AUCTION);
};

